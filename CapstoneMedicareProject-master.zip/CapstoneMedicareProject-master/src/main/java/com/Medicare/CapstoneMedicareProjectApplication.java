package com.Medicare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class CapstoneMedicareProjectApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(CapstoneMedicareProjectApplication.class, args);
	}
}
