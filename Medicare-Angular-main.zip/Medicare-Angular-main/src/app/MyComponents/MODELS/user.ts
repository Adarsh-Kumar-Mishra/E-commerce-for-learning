export class User {

    firstName:String;
    lastName:String;
    dateOfBirth:Date;
    username:String;
    password:String;
    primaryEmail:String;
    primaryPhoneNo:String;


    constructor() {}
}
