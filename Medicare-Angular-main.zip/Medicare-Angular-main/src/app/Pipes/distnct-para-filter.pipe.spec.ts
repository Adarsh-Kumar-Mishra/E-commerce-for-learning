import { DistnctParaFilterPipe } from './distnct-para-filter.pipe';

describe('DistnctParaFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DistnctParaFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
