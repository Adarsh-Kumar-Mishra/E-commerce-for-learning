import { FilterByCompanyPipe } from './filter-by-company.pipe';

describe('FilterByCompanyPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByCompanyPipe();
    expect(pipe).toBeTruthy();
  });
});
