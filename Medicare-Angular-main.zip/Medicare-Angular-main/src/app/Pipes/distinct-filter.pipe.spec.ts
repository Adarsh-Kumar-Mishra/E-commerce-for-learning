import { DistinctFilterPipe } from './distinct-filter.pipe';

describe('DistinctFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new DistinctFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
